
from general_lk_utils import (
    get_lk_credentials,
    get_listP,
    enter_ids_on_lk_signin
)
import csv
from time import sleep
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from parsel import Selector
from webdriver_manager.chrome import ChromeDriverManager

LK_CREDENTIALS_PATH = "./lk_credentials.json"
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("excludeSwitches", ['enable-automation'])
lk_credentials = get_lk_credentials(LK_CREDENTIALS_PATH)
email = lk_credentials['email']
pword = lk_credentials['password']
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

driver.get('https://www.linkedin.com/login')
sleep(2)
enter_ids_on_lk_signin(driver, lk_credentials['email'], lk_credentials['password'])
if "checkpoint/challenge" in driver.current_url:
    print(
        "It looks like you need to complete a double factor authentification. Please do so and press enter when you are done."
    )
    input()
pList = get_listP("./links.json")["links"][1]["linkCompanies"]
fields = ['Overview', 'Industry', 'Specialties']
sel = Selector(text=driver.page_source)
filEname = "./companiesScraped.csv"
# What we need from the profile


with open(filEname, 'w') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow(fields)
    for profiles in pList:
        driver.get(profiles)
        sel = Selector(text=driver.page_source)
        sleep(2)
        seeAboutBtn = driver.find_element(By.XPATH, "//a[normalize-space()='About']")
        seeAboutBtn.click()
        sleep(3)
        driver.execute_script("window.scrollBy(0, 400)")
        sleep(0.2)
        overview = driver.find_element(By.XPATH, "//p[@class='break-words white-space-pre-wrap t-black--light text-body-medium']")
        if overview:
            overview = overview.text
        else:
            overview = 'No Result'
        print(overview)
        driver.execute_script("window.scrollBy(0, 400)")
        sleep(0.2)
        industry = driver.find_element(By.XPATH,
            "(//dd[@class='mb4 t-black--light text-body-medium'])[3]")
        if industry:
            industry = industry.text
        else:
            industry = 'No Result'
        print(industry)
        try:
            specialties = driver.find_element(By.XPATH,
            "(//dd[@class='mb4 t-black--light text-body-medium'])[6]")
        except:
            specialties = driver.find_element(By.XPATH, "(//dd[@class='mb4 t-black--light text-body-medium'])[4]")
            specialties = specialties.text
        else:
            if specialties:
                specialties = specialties.text
            else:
                specialties = 'No Result'
        print(specialties)
        writer.writerow([overview, industry, specialties])
